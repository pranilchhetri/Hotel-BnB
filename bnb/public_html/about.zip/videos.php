<?php
include "header.html";
?>
    <body>
       <h1 class="signuptext" style="font-size: 280%;padding-top: 20px; text-align: center;color:#000; 
    font-family: Georgia, serif; letter-spacing: 0.05em;">Videos</h1>
        <div class="container">
            
            <div class="row mar-top-30">
               <div class="col-sm-8">
                 <div class="row">
                     
                 
                 <div class="col-sm-6">
                    <div class="box text-center">
                       <iframe src="https://www.youtube.com/embed/VnQpJu0tdwY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        <h3 class="box-tittle">Proud to be a Magar</h3>
                        <p class="box-text">A brief intro video.</p>
                    </div>
                </div>
                 <div class="col-sm-6">
                    <div class="box text-center">
                        <iframe src="https://www.youtube.com/embed/qSy8ZTddBBk" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
                        <h3 class="box-tittle">Magar Custumes</h3>
                        <p class="box-text">Intro of Magar dress.</p>
                    </div>  
               </div>
                </div>
                <div class="row">
                     
                 
                 <div class="col-sm-6">
                    <div class="box text-center">
                       <iframe src="https://www.youtube.com/embed/tzj7uMNLjpo" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        <h3 class="box-tittle">Interview with Gore Bahadur Khapangi.</h3>
                        <p class="box-text">Gore Bahadur Khapangi with his visions and goals.</p>
                    </div>
                </div>
                 <div class="col-sm-6">
                    <div class="box text-center">
                        <iframe src="https://www.youtube.com/embed/kgHjkoCMKLk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        <h3 class="box-tittle">Kauda Dance</h3>
                        <p class="box-text">Kauda Dance From Tanau district</p>
                    </div>  
               </div>
                </div>
                <div class="row">
                     
                 
                 <div class="col-sm-6">
                    <div class="box text-center">
                       <iframe src="https://www.youtube.com/embed/78EZeTbtF5A" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        <h3 class="box-tittle">Kauda Song</h3>
                        <p class="box-text">Kauda Song on the stage.</p>
                    </div>
                </div>
                 <div class="col-sm-6">
                    <div class="box text-center">
                        <iframe src="https://www.youtube.com/embed/6oL4mheTKeQ" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                        <h3 class="box-tittle">Kauda Song</h3>
                        <p class="box-text">Kauda Dance From Muna Thapa Magar and Yam Thapa Magar</p>
                    </div>  
               </div>
                </div>
                </div>
                 <div class="col-sm-4">
                    <div class="box text-center">
                    <a class="twitter-timeline" href="https://twitter.com/magardotcom?ref_src=twsrc%5Etfw">Tweets by magardotcom</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<style>
    .box {
    cursor: pointer;
    box-shadow: 0px 2px 10px -4px #333745;
    padding: 20px 0px;
    margin-bottom: 20px;
}

.incon-box i {
    font-size: 35px;
    color: #fff;
    background: #f82e56;
    height: 55px;
    width: 55px;
    line-height: 50px;
    border: 3px solid transparent;
    transition: all .4s ease-in;
}

.box-tittle {
    font-size: 20px;
    text-transform: uppercase;
    color: #333745;
    line-height: 60px;
}

.box:hover .incon-box i {
    background: #fff;
    border: 3px solid #f82e56;
    color: #f82e56;
    transition: all .4s ease-in;
}
.mar-top-30{
    margin-top: 30px;
}
.box iframe{
    width: 100%;
    height: 180px;
}
</style>