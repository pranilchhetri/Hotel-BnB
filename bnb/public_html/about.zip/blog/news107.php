<?php
include 'header1.html';
?>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<h2>
				फागुन_१५मा_मगरात_विश्व_सम्मेलन_२०१८_काठमाडौँमा_हुने
			</h2>
			<div class="row">
				<div class="col-sm-6">
				<img src="global-conference.jpg" style="width: 300px; height: auto;">	
				</div>
				<div class="col-sm-6">
					<p>
			#फागुन_१५मा_मगरात_विश्व_सम्मेलन_२०१८_काठमाडौँमा_हुने<br>
<hr>
सबैमा झोर्ले जेधो नमस्ते
नेपाल मगर संघ केन्द्रिय समिति मगर अन्तरास्ट्रिय मंचको आयोजनामा यहि २०७४ फागुन १५, १६ र १७ गते काठमाडौँमा देश बिदेशमा क्रियाशील मगर संघहरुको प्रतिनिधिहरुको प्रनिधित्वहुने गरि मगरहरुको पहिचान, सस्कार सस्कृति, भूगोल, इतिहास, मगरात बिज्ञहरुको प्रस्तुतिकरण, मगर संघको सांगठानिक समिक्षा र आगामी योजना लगायतका समसामयिक सवालमा केन्द्रीत हुने “मगरात विश्व सम्मेलन-२०१८” मा सबै मगर संघ सस्थाहरुको अनिवार्य सहभागिता हुनेगरी आयोजना गरिदै छ। सम्बधित सबैलाई आधिकारिक परिपत्र गरिने छ। अहिले लाई मात्र जानकारीको लागि राखेको छु।
धन्यवाद। जय मगरात नेपाल।।
<br><hr>
ज्ञानेन्द्र पुनमगर<br>
महासचिव, नेपाल मगर संघ केन्द्रिय समिति


			</p>
				</div>
				
			</div>
			
		</div>
		<div class="col-sm-4" style="padding-top: 30px;">
			<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FMa-garcom-408469379566486%2F&tabs=timeline&width=300&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=800910400076316" width="300" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
		</div>
	</div>
	
</div>
<?php
include "../footer.html";
?>