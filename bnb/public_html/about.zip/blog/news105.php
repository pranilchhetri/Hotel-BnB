<?php
include 'header1.html';
?>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<h2>
				हार्दिक बधाई तथा शुभकामना
			</h2>
			<div class="row">
				<div class="col-sm-6">
				<img src="sher_bahadur_roka.jpg" style="width: 300px; height: auto;">	
				</div>
				<div class="col-sm-6">
					<p>
				हार्दिक बधाई तथा शुभकामना
—-
३० जुन २०१७मा सम्पन्न नेपाल मगर संघ शाखा कतारको १२औ महादिबेसनले तत्कालीन प्रथम-उपाध्यक्ष शेरबहादुर रोकामगरको अध्यक्षतामा २७ सदसिय समिती निर्वाचित गरेको छ । नवनिर्वाचित अध्यक्ष रोका मगर लगायत सम्पूर्ण पदाधिकारी तथा सदस्यहरुमा हार्दिक बधाई तथा सफल कार्यकालको शुभकामना व्यक्त गर्दछु । महादिवेसनको उद्घाटन संघको केन्द्रीय अध्यक्ष नबिन रोकामगरले गर्नुभएको थियो ।<br>
—
ज्ञानेन्द्र पुनमगर
महासचिव, नेपाल मगर संघ केन्द्रीय समिति


			</p>
				</div>
				
			</div>
			
		</div>
		<div class="col-sm-4" style="padding-top: 30px;">
			<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FMa-garcom-408469379566486%2F&tabs=timeline&width=300&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=800910400076316" width="300" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
		</div>
	</div>
	
</div>
<?php
include "../footer.html";
?>