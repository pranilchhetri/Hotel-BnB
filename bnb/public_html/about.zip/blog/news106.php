<?php
include 'header1.html';
?>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<h2>
				नेपाल मगर संघ पाल्पाको १३ जिल्ला अधिबेशनकाे उदघाटन गर्दै संघका केन्द्रीय अध्यक्ष नवीन राेका मगर…
			</h2>
			<div class="row">
				<div class="col-sm-6">
				<img src="nepal-palpa.jpg" style="width: 300px; height: auto;">	
				</div>
				<div class="col-sm-6">
					<p>
			नेपाल मगर संघ पाल्पाको १३ जिल्ला अधिबेशनकाे उदघाटन गर्दै संघका केन्द्रीय अध्यक्ष नवीन राेका मगरले नेपालका प्रथम शहिद लखन थापा मगरको पोखरामा भत्काएका शालिक निर्माण कार्यमा कसैले नाटक गरेर राेक्न खाेजेमा कसैलाई वांकी नराख्ने चेतावनी दिदै मगर र मगरात लगायतका मुद्दामा मगरहरुले अब नयाँ ढंगले लडने समेत अपिल गर्नु भयो ।२०७४ साल असाेज २७ गते


			</p>
				</div>
				
			</div>
			
		</div>
		<div class="col-sm-4" style="padding-top: 30px;">
			<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FMa-garcom-408469379566486%2F&tabs=timeline&width=300&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=800910400076316" width="300" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
		</div>
	</div>
	
</div>
<?php
include "../footer.html";
?>