<?php
include 'header1.html';
?>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<h2>
				Greeting From Nepal Japan Magar Association
			</h2>
			<div class="row">
				<div class="col-sm-6">
				<img src="nepaljapan.jpg" style="width: 300px; height: auto;">	
				</div>
				<div class="col-sm-6">
					<p>
				Greeting From Nepal Japan Magar Association on the occassion of Makar Sankranti 2018.


			</p>
				</div>
				
			</div>
			
		</div>
		<div class="col-sm-4" style="padding-top: 30px;">
			<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FMa-garcom-408469379566486%2F&tabs=timeline&width=300&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=800910400076316" width="300" height="500" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
		</div>
	</div>
	
</div>
<?php
include "../footer.html";
?>